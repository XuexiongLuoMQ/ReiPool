Reference
=========

.. toctree::
    :glob:

    magicgraph*
