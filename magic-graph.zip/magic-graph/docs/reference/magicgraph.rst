magicgraph
=============================

.. automodule:: magicgraph
    :members:
