=====
Usage
=====

To use magic-graph in a project::

	import magicgraph
